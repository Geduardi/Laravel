<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laravel</title>
</head>
<body>

<?php include "menu.php" ?>
Добро пожаловать!
</body>
</html>
