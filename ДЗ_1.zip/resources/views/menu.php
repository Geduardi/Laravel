<a href="/">Главная</a>
<a href="/about">О нас</a>
<a href="/news">Новости</a>
<br>
