<?php include "menu.php"?>
<h1>Добро пожаловать!</h1>
