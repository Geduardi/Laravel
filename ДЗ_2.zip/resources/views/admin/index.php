<?php
include_once "menu.php";
?>
<h2>Админка</h2>
