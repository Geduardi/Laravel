<a href="<?=route('Home')?>">Главная Сайт</a>
<a href="<?=route('admin.index')?>">Главная Админка</a>
<a href="<?=route('admin.test1')?>">test 1</a>
<a href="<?=route('admin.test2')?>">test 2</a>
