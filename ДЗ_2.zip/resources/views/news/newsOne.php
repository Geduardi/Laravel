<?php include "menu.php";?>

<h2><?=$news['title']?></h2>
<p><?=$news['text']?></p>

