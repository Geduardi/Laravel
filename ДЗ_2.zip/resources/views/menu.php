<a href="<?=route('Home')?>">Главная</a>
<a href="<?=route('news.News')?>">Новости</a>
<a href="<?=route('admin.index')?>">Админка</a>
<a href="<?=route('news.NewsCategory')?>">Категория новостей</a>
<br>
